import sys
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    if line.startswith("id,") or "boneage" in line:
    parts = line.split(',')
    if len(parts) == 3:
        boneage = parts[1]
        is_male = parts[2].strip()  
        if is_male == "1": continue
        gender = "male" if is_male.lower() == "true" else "female"
        print(f"{gender}\t{boneage}")
        


