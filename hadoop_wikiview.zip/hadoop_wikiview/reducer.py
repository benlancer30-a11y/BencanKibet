import sys
current_gender = None
current_sum = 0
current_count = 0

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    parts = line.split('\t')
    if len(parts) != 2:
        continue
    gender, boneage_str = parts
    try:
        boneage = float(boneage_str)
    except ValueError:
        continue
    if current_gender == gender:
        current_sum += boneage
        current_count += 1
        else:
            if current_gender is not None:
                average_boneage = current_sum / current_count
                print(f"{current_gender}\t{avg_boneage:.2f}\t{current_count}")
        current_gender = gender
        current_sum = boneage
        current_count = 1
        if current_gender:
    avg_boneage = current_sum / current_count
    print(f"{current_gender}\t{avg_boneage:.2f}\t{current_count}")
    current_gender = None
    current_sum = 0
    current_count = 0